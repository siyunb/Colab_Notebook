from distutils.core import setup
setup(
    name = 'wangsiyu',
    version = '1.0',
    description = '第一个发布模块',
    author = 'wang',
    author_email = '240668046@qq.com',
    py_modules = ['__init__','sayhi'],
)